============================
What's new in netaddr v0.7.7
============================

.. include:: ../../CHANGELOG
